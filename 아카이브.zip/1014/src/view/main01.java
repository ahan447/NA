package view;

public class main01 {

	public static void main(String[] args) {
		new BuyView();
		

	}

}
