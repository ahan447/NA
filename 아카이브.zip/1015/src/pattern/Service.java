package pattern;

import java.util.List;
import java.util.Map;

public interface Service {
//회원정보 전체를 가져오는 메소드
	public List<Map<String, Object>>
		allMember();
	
	
}
