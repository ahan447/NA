package pattern;

import java.util.List;
import java.util.Map;

public class SeviceImpl implements Service {

	@Override
	public List<Map<String, Object>> allMember() {
		System.out.printf("메소드구현");
		return null;
	}

}
